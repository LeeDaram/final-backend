package com.example.finalEclips.eclips.mypage.dto;

import lombok.Data;

@Data
public class ReservationActivateDto {

    private String userId;
    private char isActivate;

}
