package com.example.finalEclips.eclips.dashboard.dto;

import lombok.Data;

@Data
public class UserGroupCountDto {

    private String role;
    private int roleCount;

}
