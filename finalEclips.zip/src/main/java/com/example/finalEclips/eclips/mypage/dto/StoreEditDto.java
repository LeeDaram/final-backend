package com.example.finalEclips.eclips.mypage.dto;

import lombok.Data;

@Data
public class StoreEditDto {

    private String storeName;
    private int businessRegNo;
    private String Address;
    private String mainMenu;
    private int price;
    private char isActivate;

}
