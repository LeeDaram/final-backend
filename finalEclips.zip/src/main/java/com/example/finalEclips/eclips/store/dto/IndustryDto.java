package com.example.finalEclips.eclips.store.dto;

import lombok.Data;

@Data
public class IndustryDto {
	private int industryId;
	private String industryName;
}
