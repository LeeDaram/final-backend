package com.example.finalEclips.eclips.notice.dto;

import lombok.Data;

@Data
public class NoticeRequestDto {
	private int noticeId;
	private String title;

}
