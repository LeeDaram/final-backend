package com.example.finalEclips.eclips.store.dto;

import lombok.Data;

@Data
public class StoreAddressDto {
	private String address;
	private float lat;
	private float lng;
}
