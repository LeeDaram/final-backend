package com.example.finalEclips.eclips.dashboard.dto;

import lombok.Data;

@Data
public class SidoGroupCountDto {

    private int sidoId;
    private String sidoName;
    private int approvalCount;

}
