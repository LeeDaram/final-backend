package com.example.finalEclips.eclips.store.dto;

import lombok.Data;

@Data
public class StoreRequestDto {
    private int storeId;
    private String userId;
}
