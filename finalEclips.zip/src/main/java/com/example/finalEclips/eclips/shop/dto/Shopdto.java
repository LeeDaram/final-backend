package com.example.finalEclips.eclips.shop.dto;

import lombok.Data;

@Data
public class Shopdto {
  private int industryId;
  private String industryName;
  private int count;
}
