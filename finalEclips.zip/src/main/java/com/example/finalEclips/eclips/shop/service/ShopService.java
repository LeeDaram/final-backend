package com.example.finalEclips.eclips.shop.service;

import java.util.List;

import com.example.finalEclips.eclips.shop.dto.Shopdto;

public interface ShopService {
	List<Shopdto>getAllShops();

}
