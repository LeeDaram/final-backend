package com.example.finalEclips.eclips.store.dto;

import lombok.Data;

@Data
public class SidoDto {
	private int sidoId;
	private String sidoName;
}
