package com.example.finalEclips.eclips.qna.dto;

import lombok.Data;

@Data
public class CreateQnaDto {
	private String title;
	private String content;
	private String userId;

}
