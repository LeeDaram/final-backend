package com.example.finalEclips.eclips.home.dto;

import lombok.Data;

@Data
public class HomeCountDto {
	private int totalStoreCount;  
    private int totalReviewCount; 
    private int totalUserCount; 

}
