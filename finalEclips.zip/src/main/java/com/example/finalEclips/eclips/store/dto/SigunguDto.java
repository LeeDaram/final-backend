package com.example.finalEclips.eclips.store.dto;

import lombok.Data;

@Data
public class SigunguDto {
	private int sigunguId;
	private int sidoId;
	private String sigunguName;
}
