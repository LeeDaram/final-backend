package com.example.finalEclips.eclips.user.dto;

import lombok.Data;

@Data
public class TermsDto {
    private int termsId;
    private String title;
    private String content;
    private String isRequired;
}
