package com.example.finalEclips.eclips.dashboard.dto;

import lombok.Data;

@Data
public class IndustryGroupCountDto {

    private int industryId;
    private String industryName;
    private int industryCount;

}
