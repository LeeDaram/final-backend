package com.example.finalEclips.eclips.averageprice.dto;

import lombok.Data;

@Data
public class AveragePriceDto {
    private String mainMenu;
    private String sidoName;
    private int avgPrice;
}
