package com.example.finalEclips.eclips.qna.dto;

import lombok.Data;

@Data
public class QnaRequestDto {
	private int questionId;
}
