package com.example.finalEclips.eclips.user.dto;

import lombok.Data;

@Data
public class PwReissue {

    private String userId;
    private String email;
    private String name;

}
