package com.example.finalEclips.eclips.common.dto;

public enum UserRole {

    ROLE_ADMIN, // 관리자
    ROLE_USER, // 개인 사용자
    ROLE_BIZ // 사업자

}
