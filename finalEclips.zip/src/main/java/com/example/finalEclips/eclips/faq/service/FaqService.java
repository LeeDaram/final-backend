package com.example.finalEclips.eclips.faq.service;

import java.util.List;

import com.example.finalEclips.eclips.faq.dto.FaqDto;

public interface FaqService {
	List<FaqDto> getAllFaqs();
}
