package com.example.finalEclips.eclips.user.dto;

import lombok.Data;

@Data
public class TermsAagreementDto {
    private String userId;
    private int termsId;
    private String isAgree;
}
