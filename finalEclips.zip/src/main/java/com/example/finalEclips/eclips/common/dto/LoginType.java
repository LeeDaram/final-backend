package com.example.finalEclips.eclips.common.dto;

public enum LoginType {
    LOCAL, // 로컬 로그인
    SOCIAL // 구글 소셜 로그인
}
