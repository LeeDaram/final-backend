package com.example.finalEclips.eclips.dashboard.dto;

import lombok.Data;

@Data
public class MonthGroupCountDto {

    private String yearMonth;
    private int count;

}
