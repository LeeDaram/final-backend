package com.example.finalEclips.eclips.qna.dto;

import lombok.Data;

@Data
public class CreateQnaAnswerDto {
	private int questionId;
	private String content;
}
