package com.example.finalEclips.eclips.user.dto;

import lombok.Data;

@Data
public class UserInfoUpdate {
    private UserDto userDto;
    private TermsAagreementDto termsAgreementDto;
}
