package com.example.finalEclips.eclips.qna.dto;

import lombok.Data;

@Data
public class AnswerUpdateDto {
	private int answerId;
	private String content;
}
